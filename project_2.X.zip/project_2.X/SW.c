#include"types.h"
void main(void) {
    
    TRISA = 0x00;
    TRISB = 0X03 ;
    RBPU=0;
   
    while(1)
    {        
      TripSwitchFunc();   
    }
}