#include "types.h"

void main(void) {
    
    TRISA=0x00;//Set LED_0,LED_1,LED_2,LED_3
    TRISB = 0X0B ;//SW_1, SW_2, TX & RX
    RBPU=0;
    Sys_Init();
    Can_Init();
    CANCON_Set_Mode(0);//Set Configuration Mode  the CANCON Register 
    Set_Mask();
    Set_Filter();
    Set_BaudRate();
    CANCON_Set_Mode(4);//Set Normal Mode
    
    /*Transmit Parameters*/
    TransmitBuffer = Transfer_Buffer_0;
    MsgID = 0x88;
    while(1)
    {   
        Tx_8_DataByte[1] = (SWStatus[1]<<1) | SWStatus[0];
        Tx_8_DataByte[3] = 0x02;/*Occupant Classification*/
        Tx_8_DataByte[5] =  (TripSwitchFunc()<<2);     
        Tx_Buffer(TransmitBuffer,MsgID);
        __delay_ms(5000);
        if(Rx_data_11bytes_Buffer_0[8] == 0xA0)/*Cruise Control*/
        {
            if(Rx_data_11bytes_Buffer_0[9] == 0x0E)
            {
                RA2= 1;
                __delay_ms(1000);
                RA2 = 0;
                
            }
        }
        Rx_data_11bytes_Buffer_0[8]=0x00;//Reset Value 
        Rx_data_11bytes_Buffer_0[0]=0x00;//Reset Value
    }//while
}


