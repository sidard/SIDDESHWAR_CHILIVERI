#include "types.h"
//#define LED_1 RC0
//#define LED_2 RC1

char arr_read[8];


unsigned char readEEPROM(unsigned char address)
{
    EEADR = address; //Address to be read
    EECON1bits.EEPGD = 0; //Selecting EEPROM Data Memory
    EECON1bits.RD = 1; //Initialise read cycle
    while(EECON1bits.RD);
    return EEDATA; //Returning data
}
void writeEEPROM(unsigned char address, unsigned char data)
{
    unsigned char INTCON_SAVE; //To save INTCON register value
    EEADR = address; //Address to write
    EEDATA = data; //Data to write
    EECON1bits.EEPGD = 0; //Selecting EEPROM Data Memory
    EECON1bits.WREN = 1; //Enable writing of EEPROM
    INTCON_SAVE=INTCON; //Backup INCON interupt register
    INTCON=0; //Diables the interrupt
    EECON2=0x55; //Required sequence for write to internal EEPROM
    EECON2=0xAA; //Required sequence for write to internal EEPROM
    EECON1bits.WR = 1; //Initialise write cycle
    INTCON = INTCON_SAVE; //Enables Interrupt
    EECON1bits.WREN = 0; //To disable write
    while(PIR2bits.EEIF == 0); //Checking for complition of write operation
    PIR2bits.EEIF = 0; //Clearing EEIF bit
}
/*void main(void)
{
    //TRISC = 0x00; //PORT C as output port
    
    for(char Address=0;Address<11;Address++)
    {
        //writeEEPROM(0, 00000000); //writing data to first memory location and then goes upto last location
        writeEEPROM(Address,  Rx_data_11bytes_Buffer_0[Address]);
        __delay_ms(200);
    }
    for(int Address=0;Address<11;Address++)
    {
        arr_read[Address]=readEEPROM(Address);
        __delay_ms(200);
    }
    while(1)
    {
        for(int Address=0;Address<8;Address++)
        {
            if(arr_read[Address]== Rx_data_11bytes_Buffer_0[Address])
            {
                //LED_1=1;
               // __delay_ms(2000);
                //LED_1=0;
                //__delay_ms(2000);
            }
        }
        LED_2=0;
    }
}
*/