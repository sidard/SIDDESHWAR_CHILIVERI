
// PIC18F458 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1H
#pragma config OSC = HS         // Oscillator Selection bits (HS oscillator)
#pragma config OSCS = OFF       // Oscillator System Clock Switch Enable bit (Oscillator system clock switch option is disabled (main oscillator is source))

// CONFIG2L
#pragma config PWRT = OFF       // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOR = OFF        // Brown-out Reset Enable bit (Brown-out Reset disabled)
#pragma config BORV = 25        // Brown-out Reset Voltage bits (VBOR set to 2.5V)

// CONFIG2H
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))
#pragma config WDTPS = 128      // Watchdog Timer Postscale Select bits (1:128)

// CONFIG4L
#pragma config STVR = OFF       // Stack Full/Underflow Reset Enable bit (Stack Full/Underflow will not cause Reset)
#pragma config LVP = OFF        // Low-Voltage ICSP Enable bit (Low-Voltage ICSP disabled)

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000200-001FFFh) not code protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (002000-003FFFh) not code protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (004000-005FFFh) not code protected)
#pragma config CP3 = OFF        // Code Protection bit (Block 3 (006000-007FFFh) not code protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot Block (000000-0001FFh) not code protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000200-001FFFh) not write protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (002000-003FFFh) not write protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (004000-005FFFh) not write protected)
#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (006000-007FFFh) not write protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0001FFh) not write protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000200-001FFFh) not protected from Table Reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (002000-003FFFh) not protected from Table Reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (004000-005FFFh) not protected from Table Reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (006000-007FFFh) not protected from Table Reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot Block (000000-0001FFh) not protected from Table Reads executed in other blocks)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


#include <xc.h>
#define _XTAL_FREQ  2000000
#define ConfigurationMode_0x80 0x80
#define ListenOnlyMode_0x60  0x60
#define LoopbackMode_0x40 0x40
#define DisableMode_0x20 0x20
#define NormalMode_0x00 0x00

int sys_init()
{
   // TRISAbits.RA0=1;
  // TRISBbits.RB2=0;//direction to register 2
    GIE=1;//Global Interrupt Enable
    PEIE=1;//Peripheral Interrupt Enable
  /*  if(GIE==1 && PEIE==1){//both arguments enable 
         PORTBbits.RB2=1;
         __delay_ms(1000);
         PORTBbits.RB2=0;
         __delay_ms(1000);
    }*/
    /*else if(GIE=1 && PEIE==0){
         PORTBbits.RB3=0;
        __delay_ms(5000);
    elseif(GIE==0 && PEIE==1){
            PORTBbits.RB4=0;
        __delay_ms(5000);
        }
     else{
            PORTBbits.RB5=1;
        __delay_ms(5000);
         PORTBbits.RB5=0;
    }*/
}
int CANSTAT_Fun(void)
{
    if((CANSTAT == NormalMode_0x00))
    {
        return 1;
    }
    else if((CANSTAT == DisableMode_0x20))
    {
       return 1;
    }
    else if ((CANSTAT == LoopbackMode_0x40))
    {
       return 1;
    }
    else if ((CANSTAT == ListenOnlyMode_0x60))
    {
       return 1;
    }
    else if ((CANSTAT == ConfigurationMode_0x80))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void CANCON_Fun(int mode)
{
 
    switch(mode)
    {
        case 0:
            CANCON = ConfigurationMode_0x80;// CANCON Register set to configure mode
            break;
        case 1:
            CANCON = ListenOnlyMode_0x60; // CANCON Register set to listen mode
            break;
        case 2:
            CANCON = LoopbackMode_0x40;// CANCON Register set to loop back mode
        case 3:
            CANCON = DisableMode_0x20;// CANCON Register set to disable mode
        case 4:
            CANCON = NormalMode_0x00;// CANCON Register set to normal mode
    }
}  
void can_init(){
TRISA=0X00;                             //Trisa bits are set to high
TRISBbits.RB2=0;                        //Rb2 bit is set for output
TRISBbits.RB3=1;                        //Rb3 bit is set for input
PIE3=0x02;                              //PIE3 register is set to enable
IPR3=0X02;                              //IPR3 register is set to enable

  /*  if(PIE3==0x02&&IPR3==0x02){               //check the condition is true or not 
        PORTAbits.RA0=1;
__delay_ms(1000);
PORTAbits.RA0=0;
}
else
        PORTAbits.RA0=1;
        __delay_ms(5000);
        PORTAbits.RA0=0;*/

}
int BAUD_rate()  // baud rate function
{
    BRGCON1=0xC1;  //BRGCON1 register set to be 0xc1 for 250kbps.
    BRGCON2=0xAE;   //BRGCON2 register set to be 0xAE for 250kbps.
    BRGCON3=0x45;   //BRGCON3 register set to be 0x45 for 250kbps.
   /* if((BRGCON1==0xc1)&&(BRGCON2==0xAE)&&(BRGCON3==0x45))   // condition.
        LED_BLINK();  // calling led blinking.*/
}
int ACC_FIL()    //acceptance filter function
{
    RXF0SIDH=0x00;  // RXF0SIDH register set to 0x00.
    RXF0SIDL=0x00;  // RXF0SIDL register set to 0x00.
    /*if((RXF0SIDH==0x00)&&(RXF0SIDL==0x00))  // conditions
        LED_BLINK();  // calling the blinking of LED function.*/
}
int ACC_MAS()     //acceptance mack function
{
    RXM0SIDH=0x00;  //RXM0SIDH register set to 0x00;
    RXM0SIDL=0x00;  //RXM0SIDL register set to 0x00;
    /*if((RXM0SIDH==0x00)&&(RXM0SIDL==0x00))  // conditions
        LED_BLINK();   // calling the blinking of LED function.*/

}
int LED_BLINK()   //blinking of LED function def
{

    PORTAbits.RA0=1;  
    __delay_ms(1000);
    PORTAbits.RA0=0;
   __delay_ms(1000);


}
int Write_fun(short int Transfer_buffer, short int Message_id, long int *data)
{
    //PORTBbits.RB0 = 0;
    //TRISB = 0x0;
    //selecting Transfer buffer and  setting to Normal Mode
    if(Transfer_buffer == 0)//100 = Transmit Buffer 0
    {
        CANCON = 0x08;//Set the CANCON Register with Normal Mode and Transmit Buffer 0
        //assign the Message ID High byte to TXBnSIDH (High Byte Register).
        //Assign the Message ID Low byte to TXBnSIDL (Low Byte Register).

        TXB0SIDL = (0x07 & Message_id) << 5;//for LSB 3 bits
        TXB0SIDH = (0x7F8 & Message_id) >> 3;//for MSB 8 bits

        /*if(((TXB0SIDL >> 5) + (TXB0SIDH << 3)) == Message_id)
        {


            PORTBbits.RB0 = 1;
            __delay_ms(1000);
            PORTBbits.RB0 = 0;
            
        }
        else
        {
            PORTBbits.RB0 = 1;
            __delay_ms(5000);

            PORTBbits.RB0 = 0;


        }*/



        //Set the length of the messages to 8 bytes in the TXBnDLC
        //1000 = Data Length = 8 bytes
        //0 = Transmitted message will have TXRTR bit cleared
        TXB0DLC = 0x08;


        char *msg_data = data;
        //Assign the data from the user to each byte of the TXBnDm
        TXB0D0 = *msg_data;
        msg_data++;
        TXB0D1 = *msg_data;
        msg_data++;
        TXB0D2 = *msg_data;
        msg_data++;
        TXB0D3 = *msg_data;
        msg_data++;
        TXB0D4 = *msg_data;
        msg_data++;
        TXB0D5 = *msg_data;
        msg_data++;
        TXB0D6 = *msg_data;
        msg_data++;
        TXB0D7 = *msg_data;
        msg_data++;

       //enable the TXBnCON  such that the transmitter buffer and assign the highest priority to the chosen buffer.
        TXB0CON = 0x08;
    }
    else if(Transfer_buffer == 1)//011 = Transmit Buffer 1
    {
        CANCON = 0x06;
        //assign the Message ID High byte to TXBnSIDH (High Byte Register).
        //Assign the Message ID Low byte to TXBnSIDL (Low Byte Register).

        TXB1SIDL = (0x07 & Message_id) << 5;//for LSB 3 bits
        TXB1SIDH = (0x7F8 & Message_id) >> 3;//for MSB 8 bits

        if(((TXB1SIDL >> 5) + (TXB1SIDH << 3)) == Message_id)
        {
            PORTBbits.RB0 = 1;
            __delay_ms(1000);

            PORTBbits.RB0 = 0;

        }
        else
        {
            PORTBbits.RB0 = 1;
            __delay_ms(5000);

            PORTBbits.RB0 = 0;

        }

        //Set the length of the messages to 8 bytes in the TXBnDLC
        //1000 = Data Length = 8 bytes
        //0 = Transmitted message will have TXRTR bit cleared
        TXB1DLC = 0x08;


         char *msg_data = data;
        //Assign the data from the user to each byte of the TXBnDm
        TXB1D0 = *msg_data;
        msg_data++;
        TXB1D1 = *msg_data;
        msg_data++;
        TXB1D2 = *msg_data;
        msg_data++;
        TXB1D3 = *msg_data;
        msg_data++;
        TXB1D4 = *msg_data;
        msg_data++;
        TXB1D5 = *msg_data;
        msg_data++;
        TXB1D6 = *msg_data;
        msg_data++;
        TXB1D7 = *msg_data;
        msg_data++;

       //enable the TXBnCON  such that the transmitter buffer and assign the highest priority to the chosen buffer.
        TXB1CON = 0x03;
    }
    else if(Transfer_buffer == 2)//010 = Transmit Buffer 2
    {
        CANCON = 0x04;

        //assign the Message ID High byte to TXBnSIDH (High Byte Register).
        //Assign the Message ID Low byte to TXBnSIDL (Low Byte Register).
        TXB2SIDL = (0x07 & Message_id) << 5;//for LSB 3 bits
        TXB2SIDH = (0x7F8 & Message_id) >> 3;//for MSB 8 bits

        if(((TXB2SIDL >> 5) + (TXB2SIDH << 3)) == Message_id)
        {
            PORTBbits.RB0 = 1;
            __delay_ms(1000);

            PORTBbits.RB0 = 0;

        }
        else
        {
            PORTBbits.RB0 = 1;
            __delay_ms(5000);

            PORTBbits.RB0 = 0;

        }

        //Set the length of the messages to 8 bytes in the TXBnDLC
        //1000 = Data Length = 8 bytes
        //0 = Transmitted message will have TXRTR bit cleared
        TXB2DLC = 0x08;


        char *msg_data = data;
        //Assign the data from the user to each byte of the TXBnDm
        TXB2D0 = *msg_data;
        msg_data++;
        TXB2D1 = *msg_data;
        msg_data++;
        TXB2D2 = *msg_data;
        msg_data++;
        TXB2D3 = *msg_data;
        msg_data++;
        TXB2D4 = *msg_data;
        msg_data++;
        TXB2D5 = *msg_data;
        msg_data++;
        TXB2D6 = *msg_data;
        msg_data++;
        TXB2D7 = *msg_data;
        msg_data++;

       //enable the TXBnCON  such that the transmitter buffer and assign the highest priority to the chosen buffer.
        TXB1CON = 0x03;
    }  
}
void main(void) {
  
    short int tb = 0;//Transmit Buffer 0
    int id = 0xFF;//Message ID
    long int dat = 0x1122334455667788;//Data
    TRISA = 0x00;//LED1
        sys_init();//calling the sys_init function by Rahul Team
       can_init();//calling the can_init function by Anil Team
       CANCON_Fun(0);//Set Configuration Mode  the CANCON Register
       ACC_MAS();
       ACC_FIL();
       BAUD_rate();
       CANCON_Fun(4);//Normal Mode
       
    while(1)
    {  
      /*if(CANSTAT_Fun())
       {
           LATAbits.LATA0 = 1;
            __delay_ms(1000);
           LATAbits.LATA0 = 0;
            __delay_ms(1000);
       }
       else
       {
          LATAbits.LATA0 = 1;
            __delay_ms(5000);
           LATAbits.LATA0 = 0;
            __delay_ms(5000);
       }
       */
       /*CAN TX By Eswar*/
     
       Write_fun(tb, id, &dat);
    }
}