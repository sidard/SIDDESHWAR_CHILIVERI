1. We only tested byte by byte led blinking
2. 