#include "types.h"

void main(void) {
    /*Transmit Parameters*/
    char TransmitBuffer=Transfer_Buffer_0;
    char MsgID=Instrument_Cluster_Msg_ID;
    char Cruise_Control_8Bytes[8];
    char Occ_Clas_8Bytes[8];
    char Rx_Cruise_Control_Warning_Lamp;
    char Rx_Occupant_Classification_Warning_Lamp;
    
    TRISA=0x00;//Set LED_0,LED_1,LED_2,LED_3
    TRISB = 0X0B ;//SW_1, SW_2, TX & RX
    RBPU=0;
    Sys_Init();
    Can_Init();
    CANCON_Set_Mode(0);//Set Configuration Mode  the CANCON Register 
    Set_Mask();
    Set_Filter();
    Set_BaudRate();
    CANCON_Set_Mode(4);//Set Normal Mode
    
    
    while(1)
    {   
       
        Cruise_Control_8Bytes[7] = 0x18;//Cruise Control;
        Cruise_Control_8Bytes[6] = 0x01;
        Cruise_Control_8Bytes[4] = 0x03;
        Cruise_Control_8Bytes[2] = 0x01;
        Cruise_Control_8Bytes[1] = 0xFF;
        Cruise_Control_8Bytes[0] = 0xF3;
        Tx_Buffer(TransmitBuffer,Cruise_Control_Msg_ID,Cruise_Control_8Bytes);
        __delay_ms(5000); 
        Occ_Clas_8Bytes[7] = 0x01;//Occupant;     
        Occ_Clas_8Bytes[1] = 0x0F;
        Occ_Clas_8Bytes[0] = 0x03;
        Tx_Buffer(TransmitBuffer,Occupant_Classification_Msg_ID,Occ_Clas_8Bytes);
         __delay_ms(5000); 
    }//while
}


